remove(list = ls())

require('jpeg')

# data_gals = read.csv('list_LCGs', stringsAsFactors = F)
# data_gals = read.csv('list_LCGs', stringsAsFactors = F)
data_gals = read.csv('list_CSFG.csv', stringsAsFactors = F)
# data_gals = read.csv('list_gals_paper_Vitor.csv', stringsAsFactors = F)
# data_gals = data_gals[c(1:10), ]
# data_gals = read.csv('list_LCGs_isolated', stringsAsFactors = F)

format_out = 'jpg'  # pdf (all in a single file) or jpg
pdf_output = 'teste.pdf'

nlines = 29

########################
# IF FORMAT_OUT = PDF
########################
if(format_out == 'pdf'){
  cairo_pdf(pdf_output, width = 20, height = 7, onefile = T)
  par(mfrow = c(2, 1), cex.axis = 1.5, cex.lab = 1.8)
  par(font = list(family = 'Times'))
}

for(i in 1:nrow(data_gals)){
  
  # filename = data_gals$filename[i]
  
  output_dir = sprintf('output/%4i', data_gals$plate[i])
  output_dir = gsub(' ', '0', output_dir)
  
  filename = sprintf('%4i%1s%5i%1s%4i%4s', data_gals$plate[i], '-', data_gals$mjd[i], '-', data_gals$fiberid[i], '.cxt')
  filename = gsub(' ', '0', filename)
  
  
  file_0 = sprintf('%s/%s_0comp.out', output_dir, filename)
  file_1 = sprintf('%s/%s_1comp.out', output_dir, filename)
  file_2 = sprintf('%s/%s_2comp.out', output_dir, filename)
  check_0 = file.exists(file_0)
  check_1 = file.exists(file_1)
  check_2 = file.exists(file_2)
  
  if(format_out == 'jpg'){
    output_fig_jpg = sprintf('plots_specs/%s.jpg', filename)
    check_fig = file.exists(output_fig_jpg)
  }else{
    check_fig = F
    par(mar = c(0, 7, 1, 2))
  }
  
  if(check_0 & check_1 & check_2 & !check_fig){
    
    sdss_image_file = sprintf('sdss_image/%.0f.jpg', data_gals$csfgID[i])
    sdss_image <- readJPEG(sdss_image_file, native = T)
    res_sdss_image = dim(sdss_image)[2:1]
    
    ########################
    # IF FORMAT_OUT = JPG
    ########################
    if(format_out == 'jpg'){
      jpeg(output_fig_jpg, width = 1200, height = 1000)
      par(mfrow = c(2, 1), mar = c(5, 5, 1, 1), cex.axis = 1.5, cex.lab = 1.5)
      par(font = list(family = 'Times'))
    }

    t0 = read.table(file_0, skip = 128)
    t1 = read.table(file_1, skip = 164)
    t2 = read.table(file_2, skip = 198)
    
    l_min = 3700
    l_max = max(t1$V1)
    
    plot(t1$V1, t1$V2, type = 'l', log = 'y', lwd = 2, col = 'white',
         xlim = c(l_min, l_max), xaxt = 'n',  yaxt = 'n',
         xlab = expression(paste(lambda, ' (', ring(A), ')')), 
         ylab = expression(paste(italic('F')[lambda], ' (10'^{'-17'}, ' erg', ' s'^{'-1'}, ' cm'^{'-2'}, ' ', ring(A)^{'-1'}, ')')))
    lines(t1$V1, t1$V2)
    lines(t1$V1, t1$V3, col = 'red', lwd = 2)
    lines(t2$V1, t2$V3, col = 'blue', lwd = 2)
    # lines(t0$V1, t0$V3, col = 'green', lwd = 2)
    
    legend('topleft', c(sprintf('CSBG %s', data_gals$csfgID[i]), filename), bty = 'n', cex = 2)
    # legend('topleft', c(sprintf('      CSBG %s', data_gals$csfgID[i])), bty = 'n', cex = 2)
    
    legend('topright', c('Observed', 'pPXF - one gas component', 'pPXF - two gas components'),
           lty = 1, col = c('black', 'red', 'blue'), bty = 'n', cex = 2, lwd = c(2, 2, 2))
    
    # legend('topright', c('Observed', 'pPXF                                  '), 
    #        lty = 1, col = c('black', 'blue'), bty = 'n', cex = 2, lwd = c(2, 2, 2))
    
    if(format_out == 'jpg'){
      axis(1, at = seq(3000, 12000, 500), labels = T, tcl = -0.6)
    }else{
      axis(1, at = seq(3000, 12000, 500), labels = F, tcl = -0.6)
    }
    axis(1, at = seq(3000, 12000, 100), labels = F, tcl = -0.3)
    axis(3, at = seq(3000, 12000, 500), labels = F, tcl = -0.6)
    axis(3, at = seq(3000, 12000, 100), labels = F, tcl = -0.3)
    
    xlab1 = c(0.1, 1, 10, 100, 1000, 10000); xlab1_names = c('0.1', '1', '10', '100', '1000', '1e4')
    xlab2 = vector()
    for(ll in 1:(length(xlab1) - 1)){
      xlab2 = c(xlab2, seq(xlab1[ll], xlab1[ll+1], xlab1[ll]))
    }
    axis(2, at = xlab1, labels = xlab1_names, tcl = -0.6)
    axis(2, at = xlab2, labels = F, tcl = -0.3)
    axis(4, at = xlab1, labels = F, tcl = -0.6)
    axis(4, at = xlab2, labels = F, tcl = -0.3)
    
    if(format_out == 'pdf'){par(mar = c(10, 7, 0, 2)); xlim = c(-0.8, 0.8)}else{xlim = c(-1, 1)}
    plot(t1$V1, (t1$V2 - t1$V3) / t1$V3, type = 'l', xlim = c(l_min, l_max), col = 'red',
         ylim = xlim,  xaxt = 'n', yaxt = 'n',
         xlab = expression(paste(lambda, ' (', ring(A), ')')), 
         ylab = expression(paste(delta, italic('F')[lambda], ' / ', italic('F')[lambda])))
    lines(t2$V1, (t2$V2 - t2$V3) / t2$V3, col = 'blue')
    abline(h = 0, lty = 5)
    abline(h = 0.1, lty = 3)
    abline(h = -0.1, lty = 3)
    
    flux = t1$V2
    model_line = t1$V3
    err = t1$V4
    ln_p_i = -log(sqrt(2 * pi) * err) - (flux - model_line)**2 / (2 * err**2)
    lnlike_1 = sum(ln_p_i)
    
    flux = t2$V2
    model_line = t2$V3
    err = t2$V4
    ln_p_i = -log(sqrt(2 * pi) * err) - (flux - model_line)**2 / (2 * err**2)
    lnlike_2 = sum(ln_p_i)

    n1 = length(t1$V1)
    k1 = 112 + 2 + nlines + 2
    
    n2 = length(t2$V1)
    k2 = 112 + 2 + 2 * nlines + 2 * 2
    
    bic_1 = k1 * log(n1) - 2 * lnlike_1
    bic_2 = k2 * log(n2) - 2 * lnlike_2

    aic_1 = 2 * k1 - 2 * lnlike_1
    aic_2 = 2 * k2 - 2 * lnlike_2
    
    t1 = read.table(file_1, skip = 2, nrows = 1, stringsAsFactors = F)
    vel_1 = t1$V3; sig_1 = t1$V4
    t2 = read.table(file_2, skip = 2, nrows = 2, stringsAsFactors = F)
    vel_2a = t2$V3[1]; sig_2a = t2$V4[1]
    vel_2b = t2$V3[2]; sig_2b = t2$V4[2]
    
    
    val <- substitute(paste('One gas component (vel = ' , a, ' , sig = ', b, ' km/s)'), list(a = sprintf('%.1f', vel_1), b = sprintf('%.1f', sig_1))) 
    leg_1g = do.call("expression", list(val))
    val <- substitute(paste('Two gas component (vel = ' , a, ' , sig = ', b, ' km/s)'), list(a = sprintf('%.1f', vel_2a), b = sprintf('%.1f', sig_2a))) 
    leg_2g = do.call("expression", list(val))
    val <- substitute(paste('                                 (vel = ' , a, ' , sig = ', b, ' km/s)'), list(a = sprintf('%.1f', vel_2b), b = sprintf('%.1f', sig_2b))) 
    leg_3g = do.call("expression", list(val))
    
    val <- substitute(paste('(BIC = ' , a, ' , AIC = ', b, ')'), list(a = sprintf('%.0f', bic_1), b = sprintf('%.0f', aic_1))) 
    leg_1 = do.call("expression", list(val))
    val <- substitute(paste('(BIC = ' , a, ' , AIC = ', b, ')'), list(a = sprintf('%.0f', bic_2), b = sprintf('%.0f', aic_2))) 
    leg_2 = do.call("expression", list(val))
    
    legend('topleft', c(leg_1g, leg_1,  leg_2g, leg_3g, leg_2),
           lty = 1, col = c('blue', 'white', 'red', 'white', 'white'), bty = 'n', cex = 2, lwd = c(2, 1, 2, 1))

    
    val <- substitute(paste('Gas component: ', italic(v), ' = ' , a, ' km/s , ', sigma, ' = ', b, ' km/s'), list(a = sprintf('%.1f', vel_1), b = sprintf('%.1f', sig_1))) 
    leg_1g = do.call("expression", list(val))
    # legend('topleft', leg_1g, lty = 1, col = c('blue'), bty = 'n', cex = 2, lwd = c(2, 1, 2, 1))
    if(format_out == 'pdf'){legend('bottomleft', leg_1g, bty = 'n', cex = 1.8)}
    # if(format_out == 'jpg'){legend('topleft', leg_1g, bty = 'n', cex = 2)}
    
    t1 = read.table(file_1, skip = 1, nrows = 1, stringsAsFactors = F)
    vel_stars_1 = t1$V3; sig_stars_1 = t1$V4
    
    t2 = read.table(file_2, skip = 1, nrows = 1, stringsAsFactors = F)
    vel_stars_2 = t2$V3; sig_stars_2 = t2$V4
    
    val <- substitute(paste('Stellar component:  ', italic(v), ' = ' , a, ' km/s , ', sigma, ' = ', b, ' km/s'), list(a = sprintf('%.1f', vel_stars_1), b = sprintf('%.1f', sig_stars_1))) 
    leg_stars1 = do.call("expression", list(val))
    val <- substitute(paste('Stellar component: ', italic(v), ' = ' , a, ' km/s , ', sigma, ' = ', b, ' km/s'), list(a = sprintf('%.1f', vel_stars_2), b = sprintf('%.1f', sig_stars_2))) 
    leg_stars2 = do.call("expression", list(val))
    
    legend('topright', c(leg_stars1, ' ', leg_stars2),  bty = 'n', cex = 2)
    if(format_out == 'pdf'){legend('bottomright', leg_stars1,  bty = 'n', cex = 1.8)}
    if(format_out == 'jpg'){legend('topright', leg_stars1,  bty = 'n', cex = 2)}
    
    axis(1, at = seq(3000, 12000, 500), labels = T, tcl = -0.6)
    axis(1, at = seq(3000, 12000, 100), labels = F, tcl = -0.3)
    axis(3, at = seq(3000, 12000, 500), labels = F, tcl = -0.6)
    axis(3, at = seq(3000, 12000, 100), labels = F, tcl = -0.3)
    
    axis(2, at = seq(-10, 10, 0.5), labels = T, tcl = -0.6)
    axis(2, at = seq(-10, 10, 0.1), labels = F, tcl = -0.3)
    axis(4, at = seq(-10, 10, 0.5), labels = F, tcl = -0.6)
    axis(4, at = seq(-10, 10, 0.1), labels = F, tcl = -0.3)
    
    if(format_out == 'jpg'){
      # x_0 = 6570
      # delta_x_0 = 410
      x_0 = 6400
      delta_x_0 = 540
      rasterImage(sdss_image, x_0, -1.05, x_0 + delta_x_0, -0.15)
      
      dev.off()
    }
  }
}
if(format_out == 'pdf'){
  dev.off()
}


