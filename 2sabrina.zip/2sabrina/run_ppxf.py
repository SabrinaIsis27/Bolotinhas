#!/usr/bin/env python
from __future__ import print_function
from ppxf_population_gas_example import ppxf_population_gas_example
if __name__ == '__main__':
    ppxf_population_gas_example('0426-51882-0227.cxt', 'grid_in_csfg.dat', 3722, ngas = 2, m_stars = -2, v_stars =  -35.2, s_stars = 107.0, m_gas1 = -2, v_gas1 = 0.4, s_gas1 = 60.4, v_gas2 = 0.0, s_gas2 = 100.0)
