##############################################################################################
##############################################################################################
##############################################################################################
# INPUTS
##############################################################################################
data_gals = read.csv('list_CSFG.csv', stringsAsFactors = F)
# data_gals = read.csv('list_gemini.csv', stringsAsFactors = F)
# data_gals = data_gals[!(data_gals$csfgID %in% c(1209, 4279, 4656, 10001, 12164, 13783, 15344, 17628, 18284)), ]
# data_gals = data_gals[data_gals$csfgID == 142, ]
#data_gals = read.csv('list_LCGs_neighbours', stringsAsFactors = F)
#data_gals = read.csv('list_LCGs', stringsAsFactors = F)

# output_dir = 'output_CSFG_Gemini/'
output_dir = 'output/'
log_file = 'pPXF_problems.log'
m_stars_0 = -2  # m_stars = -2 --> stellar kinematics is fixed to v_stars and s_stars. m_stars = 2 --> v_stars and s_stars are first guesses.

##############################################################################################
col_names = c('csfgID', 'filename', 'component', 'l_0')
write(col_names, file = log_file, append = F, sep = ',', ncolumns = 100)

data_gals$csfgID = c(1:nrow(data_gals))
# subdir = 'specs_Gemini'

for(i in 1:nrow(data_gals)){
  filename = data_gals$filename[i]
  
  filename = sprintf('%4i%1s%5i%1s%4i%4s', data_gals$plate[i], '-', data_gals$mjd[i], '-', data_gals$fiberid[i], '.cxt')
  filename = gsub(' ', '0', filename)

  subdir = sprintf('%4i', data_gals$plate[i])
  subdir = gsub(' ', '0', subdir)

  file_1 = sprintf('%s/%s/%s_2comp.out', output_dir, subdir, filename)
  
  # file_1 = sprintf('%s/%s/%s_2comp.out', output_dir, subdir, filename)
  check = file.exists(file_1)
  if(check == F){ 
    
    # COPY SPECTRUM TO PPXF INPUT DIRECTORY 
    #  SPECIFIED IN THE GRID FILE
    # +++++++++++++++++++++++++++++++++++++++++++++++++    
    system(sprintf('cp ./spectra/%s/%s ./spectra', subdir, filename))
    
    # DEFINE LAMBDA START
    # +++++++++++++++++++++++++++++++++++++++++++++++++
    temp = read.table(sprintf('spectra/%s/%s', subdir, filename), stringsAsFactors = F)
    if(min(temp$V1[temp$V2 > 0]) < 3700){
      l_0 = 3700
    }else{
      l_0 = min(temp$V1[temp$V2 > 0]) + 5
    }
    l_0 = l_0 - 1
    
    # PROBLEMS WITH PPXF - IT STOPS FOR SOME REASON
    #  IF IT HAPPENS, CHANGING L_0 SLIGHTLY SOLVES THE PROBLEM
    # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    try_again = T
    
    while(try_again == T){
      try_again = F  # try_again will be set to T if something goes wrong
      l_0 = l_0 + 1
      
      print('************************************************')
      print(c(filename, l_0))
      print('************************************************')
      
      # RUN PPXF TO DETERMINE STELLAR KINEMATICS
      # +++++++++++++++++++++++++++++++++++++++++++++++++
      
      write('#!/usr/bin/env python', file = 'run_ppxf.py')
      write('from __future__ import print_function', file = 'run_ppxf.py', append = T)
      write('from ppxf_population_gas_example import ppxf_population_gas_example', file = 'run_ppxf.py', append = T)
      write("if __name__ == '__main__':", file = 'run_ppxf.py', append = T)
      ppxf_command = sprintf("    ppxf_population_gas_example('%s', 'grid_in_csfg.dat', %.0f)", filename, l_0)
      write(ppxf_command, file = 'run_ppxf.py', append = T)
      
      system('python run_ppxf.py')
      
      # WAIT FOR FILE *_0comp.out
      # +++++++++++++++++++++++++
      file_1 = sprintf('%s/%s_0comp.out', output_dir, filename)
      check = file.exists(file_1)
      start_time <- Sys.time()
      time_elapsed = 0
      time_wait = 10 # seconds
      while(check == F){
        check = file.exists(file_1)
        tt = Sys.time() - start_time
        time_elapsed = abs(as.numeric(tt))
        if(time_elapsed > time_wait){
          check = T; n_comp = 0; try_again = T
          temp = c(data_gals$csfgID[i], filename, n_comp, l_0)
          write(temp, file = log_file, append = T, sep = ',', ncolumns = 100)
        }
      }
      
      if(try_again == F){
        # RUN PPXF WITH 1 GAS COMPONENTS (STELLAR KINEMATICS IS FIXED)
        # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
        t1 = read.table(file_1, skip = 1, nrows = 1, stringsAsFactors = F)
        vel_stars_1 = t1$V3; sig_stars_1 = t1$V4
        
        # if(sig_stars_1 > 200 | abs(vel_stars_1) > 100){
        #   m_stars = -2; vel_stars_1 = 0; sig_stars_1 = 50
        #   write('#!/usr/bin/env python', file = 'run_ppxf.py')
        #   write('from __future__ import print_function', file = 'run_ppxf.py', append = T)
        #   write('from ppxf_population_gas_example import ppxf_population_gas_example', file = 'run_ppxf.py', append = T)
        #   write("if __name__ == '__main__':", file = 'run_ppxf.py', append = T)
        #   ppxf_command = sprintf("    ppxf_population_gas_example('%s', 'grid_in_csfg.dat', %.0f, ngas = 0, m_stars = %.0f, v_stars =  %.1f, s_stars = %.1f)", 
        #                          filename, l_0, m_stars, vel_stars_1, sig_stars_1)
        #   write(ppxf_command, file = 'run_ppxf.py', append = T)
        #   
        #   system('python run_ppxf.py')
        #   
        #   file_1 = sprintf('%s/%s_0comp.out', output_dir, filename)
        #   check = file.exists(file_1)
        #   start_time <- Sys.time()
        #   time_elapsed = 0
        #   time_wait = 10 # seconds
        #   while(check == F){
        #     check = file.exists(file_1)
        #     tt = Sys.time() - start_time
        #     time_elapsed = abs(as.numeric(tt))
        #     if(time_elapsed > time_wait){
        #       check = T; n_comp = 0; try_again = T
        #       temp = c(data_gals$csfgID[i], filename, n_comp, l_0)
        #       write(temp, file = log_file, append = T, sep = ',', ncolumns = 100)
        #     }
        #   }
        # }else{
        #   m_stars = m_stars_0
        # }
        if(sig_stars_1 > 2000){m_stars = 2}else{m_stars = m_stars_0}
        # m_stars = m_stars_0
        
        write('#!/usr/bin/env python', file = 'run_ppxf.py')
        write('from __future__ import print_function', file = 'run_ppxf.py', append = T)
        write('from ppxf_population_gas_example import ppxf_population_gas_example', file = 'run_ppxf.py', append = T)
        write("if __name__ == '__main__':", file = 'run_ppxf.py', append = T)
        ppxf_command = sprintf("    ppxf_population_gas_example('%s', 'grid_in_csfg.dat', %.0f, ngas = 1, m_stars = %.0f, v_stars =  %.1f, s_stars = %.1f, v_gas1 = %.1f, s_gas1 = %.1f)", 
                               filename, l_0, m_stars, vel_stars_1, sig_stars_1, 0, 100)
        write(ppxf_command, file = 'run_ppxf.py', append = T)
        
        system('python run_ppxf.py')
        
        # WAIT FOR FILE *_1comp.out
        # +++++++++++++++++++++++++
        file_1 = sprintf('%s/%s_1comp.out', output_dir, filename)
        check = file.exists(file_1)
        start_time <- Sys.time()
        time_elapsed = 0
        while(check == F){
          check = file.exists(file_1)
          tt = Sys.time() - start_time
          time_elapsed = abs(as.numeric(tt))
          if(time_elapsed > time_wait){
            check = T; n_comp = 1; try_again = T
            temp = c(data_gals$csfgID[i], filename, n_comp, l_0)
            write(temp, file = log_file, append = T, sep = ',', ncolumns = 100)
          }
        }
        
        if(try_again == F){
          # RUN PPXF WITH 2 GAS COMPONENTS (STELLAR KINEMATICS IS FIXED)
          # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
          
          t1 = read.table(file_1, skip = 1, nrows = 1, stringsAsFactors = F)
          vel_stars_1 = t1$V3; sig_stars_1 = t1$V4
          m_stars = -2   # fix stellar component to fit 2 gas component
          m_gas1 = -2   # fix gas component 1 to fit 2nd gas component
          
          t1 = read.table(file_1, skip = 2, nrows = 1, stringsAsFactors = F)
          vel_gas_1 = t1$V3; sig_gas_1 = t1$V4
          
          write('#!/usr/bin/env python', file = 'run_ppxf.py')
          write('from __future__ import print_function', file = 'run_ppxf.py', append = T)
          write('from ppxf_population_gas_example import ppxf_population_gas_example', file = 'run_ppxf.py', append = T)
          write("if __name__ == '__main__':", file = 'run_ppxf.py', append = T)
          ppxf_command = sprintf("    ppxf_population_gas_example('%s', 'grid_in_csfg.dat', %.0f, ngas = 2, m_stars = %.0f, v_stars =  %.1f, s_stars = %.1f, m_gas1 = %.0f, v_gas1 = %.1f, s_gas1 = %.1f, v_gas2 = %.1f, s_gas2 = %.1f)", 
                                 filename, l_0, m_stars, vel_stars_1, sig_stars_1, m_gas1, vel_gas_1, sig_gas_1, 0, 100)
          write(ppxf_command, file = 'run_ppxf.py', append = T)
          
          system('python run_ppxf.py')
          
          # WAIT FOR FILE *_2comp.out
          # +++++++++++++++++++++++++
          file_1 = sprintf('%s/%s_2comp.out', output_dir, filename)
          check = file.exists(file_1)
          start_time <- Sys.time()
          time_elapsed = 0
          while(check == F){
            check = file.exists(file_1)
            tt = Sys.time() - start_time
            time_elapsed = abs(as.numeric(tt))
            if(time_elapsed > time_wait){
              check = T; n_comp = 2; try_again = T
              temp = c(data_gals$csfgID[i], filename, n_comp, l_0)
              write(temp, file = log_file, append = T, sep = ',', ncolumns = 100)
            }
          }
        }
      }
    }

    # COPY SPECTRUM TO PPXF INPUT DIRECTORY 
    #  SPECIFIED IN THE GRID FILE
    # +++++++++++++++++++++++++++++++++++++++++++++++++    
    system(sprintf('rm ./spectra/%s', filename))
    
    # COPY OUTPUT FILES TO SUBDIR
    # +++++++++++++++++++++++++++++++++++++++++++++++++ 
    dir = sprintf('./%s/%s', output_dir, subdir)
    check = file.exists(dir)
    if(check == F){system(paste('mkdir ', dir))}
    
    system(sprintf('mv ./%s/%s* %s/%s/', output_dir, filename, output_dir, subdir))
    
  }else{
    print(sprintf('Files for %s already exist', filename))
  }
  
}


    
